# Lab 4: Solution Deployment

This report describes *where* the HMS runs and *which* architectural decisions shaped that topology. The Solution Architecture (Lab 2) fixed the logical structure — a modular monolith ASP.NET Core API, a React + TypeScript SPA, an MS SQL Server backend, and OIDC-based identity. Lab 4 turns those choices into concrete infrastructure: a static SPA at the edge (Vercel), an Azure-hosted API + database tier, a Hangfire worker for asynchronous notifications, and managed observability/secrets services. A working prototype is already deployed (`hospital-management-system-demo.vercel.app`); the diagram below captures the **target** production topology that this prototype will grow into.

## 1. Deployment View

Figure 4.1 is the deployment diagram of the HMS. Nodes are drawn in the C4 *Deployment* style — boxes are deployment nodes, inner rounded rectangles are artefacts. Solid arrows are synchronous HTTPS/TDS calls; dashed arrows are asynchronous or out-of-band (events, logs, secret fetches). External systems sit in the lower band; the Azure resource group sits in the upper-right band.

![](./assets/hms-deployment.drawio.svg)
*Figure 4.1. C4 Deployment Diagram of the Hospital Management System (target topology).*

### 1.1 Nodes and artefacts

*Table 4.1. Deployment nodes*

| Node | Type | Purpose |
| :-- | :-- | :-- |
| Hospital staff device | Client | Chromium-based browser, laptop or mobile. Mutual-TLS not required (public web). Only authenticated staff roles use the system; patients interact in person via Reception and Billing (Lab 2 §3). |
| **Vercel — Edge / CDN** | Managed FE host | Serves the **Staff Portal SPA** artefact (React + TypeScript bundle) globally; HTTPS termination at the edge; auto-deploy on `main` from GitHub. |
| **Azure App Service Plan (Linux, P1v3)** | Managed compute | Hosts three artefacts: the **HMS API** (ASP.NET Core 8 Web API), the **Identity Provider** (ASP.NET Core Identity / OIDC, co-located in v1), and the **Notification Worker** (Hangfire process for reminders, restock alerts and discharge notices). |
| **Azure SQL Database** | Managed DB | Hosts the **HMS Database** artefact — 3NF schema and ECA triggers from Lab 1; geo-redundant backups, point-in-time restore (PITR). Reached from the API via private endpoint inside the VNet. |
| **Azure Application Insights** | Observability | Collects logs, traces, custom metrics; alerts on error rate, p95 latency, and allergy-block frequency. |
| **Azure Key Vault** | Secrets | Stores DB connection strings, JWT signing keys, SendGrid / Twilio tokens, Insurance partner certificates. Accessed via managed identity. |
| **Private VNet + Private Endpoint** | Network | Restricts API ↔ SQL traffic to the private network; only the API egress IP can reach the DB. |
| **GitHub repository** `Hospital-Management-System-demo` | Source control + CI | Vercel pulls the SPA on push; GitHub Actions builds the API container image and deploys to App Service. |
| Email/SMS Gateway (SendGrid + Twilio) | External | Delivery of reminders, discharge notices, restock alerts. |
| Insurance Co. API | External | Receives billing/eligibility exports (REST, mTLS). |
| Pharmacy Supplier API | External | Receives restock orders. |
| Azure Identity (Entra) | External (planned) | Reserved as a federation target if the bundled Identity Provider is later extracted. |

### 1.2 Communication paths

*Table 4.2. Key communication paths*

| From | To | Protocol | Notes |
| :-- | :-- | :-- | :-- |
| Browser | Vercel edge | HTTPS 443 | Static asset fetch + SPA boot. |
| SPA → HMS API | HMS API | HTTPS `/api/v1/*` | JWT bearer issued by IdP; CORS allow-list pinned to the Vercel domain. |
| Browser → IdP | Identity Provider | OIDC redirect (HTTPS) | Auth code + PKCE. |
| HMS API → SQL | Azure SQL | TDS over private endpoint | EF Core; least-privilege SQL user. |
| HMS API → Worker | Hangfire | DB-backed queue | Worker reads jobs from the same SQL instance. |
| Worker → Gateway | SendGrid / Twilio | HTTPS | Async fan-out from `PrescriptionIssued`, `Discharged`, `RestockLow` events. |
| HMS API → Insurance Co. | Insurance API | HTTPS + mTLS | Outbound only, retried with exponential backoff. |
| HMS API → Pharmacy Supplier | Supplier API | HTTPS | Outbound only. |
| HMS API → App Insights / Key Vault | Azure services | HTTPS, managed identity | Telemetry + secret retrieval. |
| GitHub → Vercel / App Service | CI/CD | HTTPS | Vercel via Git integration; App Service via GitHub Actions OIDC. |

### 1.3 Environments

Three environments share the same topology, each in its own Azure resource group: **`dev`** (developer integration, Basic-tier App Service and DB), **`staging`** (mirrors prod, used for UAT and load tests), **`prod`** (Standard/Premium tiers, geo-redundant backups). Vercel adds an additional **preview deployment per pull request**, so frontend changes can be reviewed against the live API in `staging` before merging.

### 1.4 Current vs target state

The live deployment today is the **prototype SPA only** — a static React 18 / Babel-standalone build hosted on Vercel. The API, Identity Provider, Worker, App Insights, Key Vault, VNet, and Azure SQL tiers in Figure 4.1 represent the **target** production topology defined by Lab 2 and Lab 3. ADR-006 and ADR-007 below record this staged rollout explicitly.

## 2. Architecture Decisions (ADR Table)

The decisions below are the ones that most constrain the deployment: hosting choice, persistence, identity, eventing, and CI/CD. Each row cites the quality goal from Lab 2 that it serves (QG1 Reliability, QG2 Security, QG3 Performance, QG4 Modifiability, QG5 Integrability).

*Table 4.3. Architecture Decision Record (ADR)*

| ID | Decision | Context / Driver | Rationale |
| :-- | :-- | :-- | :-- |
| ADR-001 | Use **cloud-based hosting** for application deployment. | Need for scalability and high availability; small hospital ops team. *Drives:* QG3, QG4. | Managed PaaS removes patching, scaling, and DR burden; allows multi-environment parity with the same Azure resource templates. |
| ADR-002 | Implement the backend as a **modular monolith** on the API tier (single deployable, internal modules per bounded context). | Small team, transactional integrity required across clinical and billing workflows. *Drives:* QG1, QG4. | Avoids distributed-transaction complexity; keeps allergy/clearance invariants enforceable inside one process; modules can be extracted to services later. |
| ADR-003 | Persist data in **MS SQL Server (Azure SQL)** with 3NF schema + ECA triggers + stored procedures for invariants. | Patient safety rules must hold regardless of the calling service. *Drives:* QG1, QG2. | DB-level enforcement provides defence-in-depth; continuity with Lab 1 design; Azure SQL provides geo-redundant backup and PITR with no DBA work. |
| ADR-004 | Build the API with **ASP.NET Core 8 Web API + EF Core**. | Strong typing, native SQL Server integration, mature security stack. *Drives:* QG1, QG2. | First-class policy-based authorization and Identity packages; performance suitable for the 2-second p95 budget. |
| ADR-005 | Build the frontend as a **React + TypeScript SPA** (with a stand-in React 18 / Babel-standalone prototype during early iterations). | Role-specific dashboards with many constrained form fields. *Drives:* QG4. | TypeScript reduces defects on the many cross-field validations (DOB, room gender, business hours); React component model maps 1-to-1 to the IA in Lab 2. |
| ADR-006 | Host the SPA on **Vercel** with GitHub Git integration; auto-deploy on `main` and preview deployments per PR. | Static asset delivery, low ops, fast review cycles. *Drives:* QG3, QG4. | Edge CDN gives sub-100 ms TTFB globally; PR previews unblock UX review without staging seats; current live URL `hospital-management-system-demo.vercel.app` is the working artefact. |
| ADR-007 | Host the API tier on **Azure App Service** and the database on **Azure SQL Database**, networked over a private endpoint inside a VNet. | Managed PaaS, regulated-data isolation, single-cloud ops. *Drives:* QG2, QG3, QG4. | Co-locates compute and storage in the EU region for data-protection; managed scaling and patching; private endpoint blocks public DB access. |
| ADR-008 | Authenticate users via **OAuth 2.0 / OpenID Connect** with role claims; combine policy-based authZ at the API and row-level filters in EF Core. | Multi-role staff and patient access; HR-enforced hospital-email policy. *Drives:* QG2. | Tokens carry role claims that match Lab 3 RBAC matrix; row-level filters guarantee that "own records only" rules (Patient → own bills) cannot be bypassed by tampering with query parameters. |
| ADR-009 | Expose **REST + JSON** APIs versioned at `/api/v1/...`; use **MediatR** for in-process domain events. | External integrators expect REST; future service extraction needs an event seam. *Drives:* QG4, QG5. | REST is predictable for Insurance/Pharmacy partners; versioned URL prevents breaking external consumers; MediatR keeps modules loosely coupled today and prepares the ground for a message-broker swap. |
| ADR-010 | Run a **Hangfire-based Notification Worker** for asynchronous fan-out (reminders, discharge notices, restock alerts). | Outbound gateway latency must not block clinical API calls; retries needed. *Drives:* QG1, QG3. | DB-backed queue eliminates a separate broker; Hangfire dashboard gives operators visibility into stuck jobs; co-locates with API on the same App Service plan in v1. |
| ADR-011 | Centralise observability in **Azure Application Insights** and secrets in **Azure Key Vault** (managed identity for access). | Operational incidents must be diagnosable; secrets must not live in source. *Drives:* QG1, QG2. | App Insights correlates HTTP, EF, and worker telemetry; Key Vault rotates JWT keys and partner certificates without redeploys. |
| ADR-012 | Adopt **trunk-based development**; CI runs build + unit tests + integration tests against a **real SQL Server container** (no DB mocks). | Triggers and stored procedures must be exercised by tests, not mocked away. *Drives:* QG1. | Mocking the DB would let allergy/clearance rules drift between code and triggers; the integration-test layer catches that class of bug pre-merge. |

## 3. Verification

To confirm the deployment matches the description above:

1. **Live frontend** — open `https://hospital-management-system-demo.vercel.app/` and verify that the screens documented in Lab 3, render (Login → Dashboard → Patients → Appointments → Admissions → Prescriptions → Billing / Pharmacy / Ambulance / Staff). The Vercel project should show the most recent commit on `main` as the production deployment.
2. **CI/CD plumbing** — push a small commit to a feature branch and confirm (a) GitHub Actions completes the API build (target environments only) and (b) Vercel posts a preview URL on the pull request.
3. **API smoke (target state, once API is deployed)** — `curl https://<api-host>/api/v1/healthz` returns `200`; `curl -X POST .../v1/prescriptions` with a known allergen returns `409 Conflict` (UC-PRESC-01 happy/sad paths from Lab 3).
4. **Discharge clearance** — attempt `POST /v1/admissions/{id}/discharge` for a patient with an unpaid bill and confirm `409 Conflict`; settle the bill and retry to confirm `200 OK`.
5. **Observability** — the test calls from step 3 appear in App Insights within 60 s; an audit-log entry for the allergy block is visible via `GET /v1/admin/audit` (Admin role).

---
[back](../README.md)