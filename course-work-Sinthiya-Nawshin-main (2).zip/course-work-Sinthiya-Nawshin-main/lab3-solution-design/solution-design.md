# Lab 3: Solution Design

This report turns the Lab 2 architecture into a concrete design for the Hospital Management System (HMS). Each section uses UML notation to specify *what* the system does (use cases), *how it looks* (UI), *how it is built* (components, domain model), *how it behaves at run-time* (state machine, sequence), and *how it is exposed* (REST API + RBAC). Where decisions were already made in Lab 1 (domain) or Lab 2 (architecture), they are referenced rather than restated. A working visual prototype (React 18 SPA, deployed to Vercel at `hospital-management-system-demo.vercel.app`) accompanies this design and is used as the source for the wireframes.

## 1. System Features View

### 1.1 UML Use Case Diagram
Figure 3.1 shows the system-level use cases and the actors that initiate them. Actors are the internal-actor set from Lab 1 & 3 (Receptionist, Doctor, Billing Officer, Supply Clerk, Ambulance Manager, HR Manager, Admin) plus the one external system that drives a use case — the **Insurance Company** (consumes the bill export). **Patient** is listed in Lab 1 & 3 as an external stakeholder but is not a system actor: patient-facing interactions in this version are intermediated by Reception, Doctor and Billing staff. The use-case set is the operational projection of the *Essential Features*. The four yellow ellipses are `«include»` sub-use-cases — they represent invariants the system always evaluates and are the design-time hooks for the ECA rules introduced in Lab 1. 

![](./Assets/hms-use-cases.drawio.svg)
*Figure 3.1. UML Use Case Diagram of the Hospital Management System*

### 1.2 Main Use Case Specification — Prescribe Medication with Allergy Check
The Prescribe-with-allergy-check flow is the most safety-critical scenario in the system (Lab 1, Issue I03; Lab 2, Quality Goal 1 — Reliability/Functional Correctness). It is therefore the main use case formalized here.

*Table 3.1. Use Case Specification — UC-PRESC-01*

| Field | Content |
| :-- | :-- |
| ID | UC-PRESC-01 |
| Name | Prescribe Medication with Allergy Check |
| Primary actor | Doctor |
| Secondary actors | Patient (notified), Notification Service |
| Stakeholders & interests | Patient — must not receive a medication that conflicts with a recorded allergy. Doctor — needs an unambiguous block + reason. Billing — must record the prescription against the patient ledger. Hospital — must keep an auditable record of every allergy block. |
| Preconditions | Doctor is authenticated and holds the `Doctor` role; the Patient exists and has at least one open clinical record. |
| Trigger | Doctor submits a prescription form on the Prescriptions page. |
| Main success scenario | 1. Doctor opens the patient profile. 2. Doctor selects medication and dosage. 3. System loads `Patient.Allergies`. 4. `AllergyCheckPolicy` evaluates medication against allergies and returns no conflict. 5. System persists the prescription (DB trigger re-validates as last line of defence). 6. System publishes `PrescriptionIssued`. 7. Notification Service sends an SMS to the patient. 8. System returns `201 Created` to the Doctor. |
| Extensions (alternates) | **4a.** `AllergyCheckPolicy` reports a conflict → system blocks the prescription, returns `409 Conflict` with the offending allergen, displays the `AllergyBadge` warning on the UI, and writes an audit-log entry (`AllergyBlockTriggered`). The use case ends without persistence. **5a.** DB trigger detects an inconsistency → returns `409`, transaction rolls back. |
| Postconditions (success) | A `Prescription` aggregate is persisted; a `PrescriptionIssued` event is in the outbox; an SMS is dispatched (asynchronously). |
| Postconditions (failure) | No `Prescription` is persisted; an `AllergyBlockTriggered` audit entry exists. |
| Non-functional notes | Response within 2 s under peak load; all PII transmitted under TLS; rule enforced both in the application layer (`PrescriptionService`) and at the DB layer. |
| Components involved | `PrescriptionController` → `PrescriptionService` → `AllergyCheckPolicy` → `PatientRepository` → DB; `EventBus (MediatR)` → `NotificationPublisher` → `Notification Service` (see Fig. 3.4 and Fig. 3.7). |

### 1.3 Activity Diagram
Figure 3.2 traces the prescribe flow at the activity level. The yellow diamond is the ECA branch; the red branch reproduces the "block + log + warn" sequence enumerated in Extension 4a above.

![](./Assets/hms-activity-prescribe.drawio.svg)
*Figure 3.2. Activity Diagram — Prescribe Medication with Allergy Check*

## 2. UI Design

The frontend technology is React + TypeScript SPA. A working visual prototype was built with **React 18** loaded via UMD plus **Babel-standalone** so it runs as a single static `index.html` without a build step. It is hosted on **Vercel** via the GitHub integration in this repository and is the source for the wireframes below. The Information Architecture is the one defined in Lab 2 (Figure 2.4); each screen below maps to one top-level IA section.

*Table 3.2. Prototype technology summary*

| Layer | Technology |
| :-- | :-- |
| Markup | Single `index.html` with `#root` mount |
| Component runtime | React 18 (UMD build) |
| JSX transform | Babel-standalone 7.29 (in-browser) |
| Styling | Hand-written `styles.css` (Inter + JetBrains Mono fonts) |
| State | In-component React state + a shared `data.jsx` seed dataset |
| Hosting | Vercel (CDN edge, GitHub Git integration) |
| Source | `Sinthiya-Nawshin/Hospital-Management-System-demo` |

This stand-in is technically a UMD-based static prototype, not the production `React + TypeScript` SPA that Lab 2 specifies — but it preserves the same component decomposition (one JSX file per page, a single shell, and a shared widgets file), which makes it usable directly as wireframes. The full prototype source is preserved in `Assets/prototype/` (`app-shell.jsx`, `app.jsx`, `data.jsx`, `shared.jsx`, `page-*.jsx`, `styles.css`, `index.html`).

### 2.1 Wireframes

**Appointments — Day and Week view** (Fig. 2.1 & 2.2) — implements *IA → Appointments* and Feature *Appointment Scheduling*. The colour legend (Consultation / Follow-up / Check-in / Procedure / Urgent) reifies the appointment-type enum; the "Business hours 09:00–17:00" caption is the UI surface of the `BusinessHoursPolicy` invariant (Lab 1 ECA rule). The sidebar shows two visibility classes: **Workspace** (always-on staff modules) and **Other modules** (lock-icon on Prescriptions / Billing / Pharmacy / Staff).

![](./Assets/wireframes/hms-appointments-day.png)
*Figure 2.1. Wireframe — Appointments page (Day view)*

![](./Assets/wireframes/hms-appointments-week.png)
*Figure 2.2. Wireframe — Appointments page (Week view)*

**Dashboard** (`page-dashboard.jsx`) — role-aware landing page. Top-of-page greeting + KPI grid (e.g., "allergy blocks today", "rooms free", "bills pending clearance"), followed by a 2-column "Today's schedule + Activity" card row, then a 3-column row with "Ward occupancy", "Pending bills" and a third KPI (Dashboard alerts).

![](./Assets/wireframes/hms-dashboard.png)
*Figure 2.3. Wireframe — Dashboard page*

**Patients** (`page-patients.jsx`) — left: searchable patient list with the `12` count badge mirrored in the sidebar (Fig. 2.4); right: detail header with allergy badges + five tabs (`Overview`, `History`, `Prescriptions`, `Admissions`, `Bills`) matching the prototype implementation. The `History` tab is currently a placeholder for the `MedicalRecord` aggregate (`GET /v1/patients/{id}/medical-record`); the allergy block in the header is the data feed for UC-PRESC-01. Implements *IA → Patients* and Feature *Patient Registration* (and exercises the new `PatientAgePolicy` invariant when a new patient is added).

![](./Assets/wireframes/hms-patients.png)
*Figure 2.4. Wireframe — Patients page*

**Admissions** (`page-admissions.jsx`) — the room board: rooms grouped by ward, each card colour-coded by `allowedGender`, beds shown as occupied/free. Implements *IA → Admissions & Rooms* and the `RoomAllocationPolicy` invariant.

![](./Assets/wireframes/hms-admission-ward.png)
*Figure 2.5. Wireframe — Admission & Ward page*

**Prescriptions** (`page-prescriptions.jsx`) — left: medication picker with autocomplete; right: live preview of "Active prescriptions" for the patient. When the user selects a medication the patient is allergic to, the form surfaces a red `AllergyBadge` and the **Issue** button becomes disabled. 

![](./Assets/wireframes/hms-prescriptions.png)
*Figure 2.6. Wireframe — Prescription page*

**Login** (`page-login.jsx`) — single email + password form, OIDC redirect; HR-policy-enforced hospital-email validation hint under the email field.

![](./Assets/wireframes/hms-login-page.png)
*Figure 2.7. Wireframe — Login page*

**Billing / Pharmacy Inventory / Ambulance / Staff** (`page-misc.jsx`) — four supporting screens for *IA → Billing*, *IA → Pharmacy*, *IA → Ambulance*, *IA → Staff*. Each follows the same shell-of-table-of-rows pattern; the Billing screen exposes both the **Clear for discharge** action (triggers `DischargeClearancePolicy`) and the **Export to insurance** action (calls `POST /v1/bills/export/insurance`). The Staff screen is also the Admin sub-view entry-point for role management and the audit log.

![](./Assets/wireframes/hms-billing-discharge.png)
*Figure 2.8. Wireframe — Billing & Discharge page*

![](./Assets/wireframes/hms-medicine-inventory.png)
*Figure 2.9. Wireframe — Pharmacy Inventory page*

![](./Assets/wireframes/hms-ambulances.png)
*Figure 2.10. Wireframe — Ambulance page*

![](./Assets/wireframes/hms-staff-departments.png)
*Figure 2.11. Wireframe — Staff & Departments page*


The live deployment (`hospital-management-system-demo.vercel.app`) reflects all of the above and is the authoritative source if any wireframe drifts from the prototype source.

## 3. Structural View

### 3.1 Client-Side Architecture
Figure 3.1 shows the React SPA decomposed into shell, route-level pages, shared widgets, and a data/cross-cutting layer. The page list mirrors the prototype's `page-*.jsx` files one-for-one, so the design is traceable to a running artefact.

![](./Assets/hms-client-components.drawio.svg)
*Figure 3.1. UML Component Diagram — Client-side (React + TypeScript SPA)*

### 3.2 Server-Side Architecture
Figure 3.2expands the modular monolith introduced in Lab 2 (Fig. 2.2, Fig. 2.3). Components are laid out as four horizontal bands — **Controllers** (inbound), **Application Services** (use cases), **Domain Services / Policies** (invariants), **Repositories** (outbound) — plus a cross-cutting band. The four yellow policies are the design-time homes of the ECA rules from Lab 1.

![](./Assets/hms-server-components.drawio.svg)
*Figure 3.2. UML Component Diagram — Server-side (ASP.NET Core Web API)*

### 3.3 Domain Model
Figure 3.3 is the class diagram for the HMS domain. Aggregate roots are drawn in green (`Appointment`, `Admission`, `Prescription`, `Bill`); supporting entities are yellow. Invariants are inscribed inside each aggregate (`{inv: ...}`) so that the domain model itself records the safety rules — the policies in Figure 3.5 are the runtime enforcers of those invariants.

![](./Assets/hms-domain-model.drawio.svg)
*Figure 3.3. UML Class Diagram — HMS Domain Model*

Key invariants encoded:
- `Patient.dob ≤ today` — enforced by `PatientAgePolicy` on registration and on every PATCH; future-dated births are rejected with `400 invalid_dob` (Lab 1 intro safety rule).
- `Appointment.slot ∈ businessHours` and "no overlap per doctor" — enforced by `BusinessHoursPolicy` + `AppointmentScheduler`.
- `Admission.room.allowedGender == patient.gender` and `discharge ⇒ no unpaid bills` — enforced by `RoomAllocationPolicy` + `DischargeClearancePolicy`.
- `Prescription.noAllergyConflict` — enforced by `AllergyCheckPolicy` matching `Patient.Allergies[].substance` against `Medication.allergenTags[]`, `Medication.name`, and `Medication.class` (this matches the prototype's algorithm in `page-prescriptions.jsx`).
- `Medication.price > 0`, `Medication.stock ≥ 0` — enforced by `StockPositivityPolicy` + DB CHECK constraints.
- `Ambulance.plate` is unique — DB UNIQUE constraint.
- `Doctor.email` matches hospital domain — `EmailDomainPolicy` (HR).
- `Patient.mrn` is unique — DB UNIQUE constraint.

## 4. Run-Time View

### 4.1 State Machine — Admission lifecycle
Figure 4.1 models the `Admission` aggregate's lifecycle. The guard `[no unpaid bills]` on the `confirmDischarge()` transition is the run-time projection of the `DischargeClearancePolicy` invariant; the `[bills unpaid] / block` self-loop documents that the system bounces the request back to `InTreatment` instead of failing silently.

![](./Assets/hms-state-admission.drawio.svg)
*Figure 4.1. UML State Machine Diagram — Admission lifecycle*

### 4.2 Sequence — Prescribe Medication with Allergy Check
Figure 4.2 traces UC-PRESC-01 across the runtime collaborators: browser → API → application service → policy → repository → DB, with the success branch fanning out to the in-process event bus and the asynchronous Notification Service. The two `alt` fragments correspond directly to the Main success scenario and Extension 4a in Table 3.1.

![](./Assets/hms-sequence-prescribe.drawio.svg)
*Figure 4.2. UML Sequence Diagram — Prescribe Medication with Allergy Check*

## 5. API Specification & RBAC

All endpoints are versioned under `/api/v1/`. Request and response bodies are JSON. Authentication is `Authorization: Bearer <JWT>` issued by the Identity Provider. All write endpoints can return `400` (validation), `401` (missing/expired token), `403` (role denied), and `409` (business-rule conflict — allergy, business-hours, gender mismatch, unpaid bill); these are not repeated in every row to keep the table readable.

### 5.1 API Specification

*Table 3.3. REST API specification (v1)*

| HTTP | Endpoint | Request Body | Response Body | Status Codes |
| :-- | :-- | :-- | :-- | :-- |
| POST | `/v1/auth/login` | `LoginDto {email, password}` | `TokenDto {accessToken, refreshToken, role}` | 200, 401 |
| POST | `/v1/auth/refresh` | `RefreshDto {refreshToken}` | `TokenDto {…}` | 200, 401 |
| POST | `/v1/patients` | `PatientCreateDto {mrn, fullName, dob, gender, bloodType, contact, insurerId?}` | `PatientDto {id, …}` | 201, 400 (incl. `invalid_dob` if `dob > today`) |
| GET | `/v1/patients/{id}` | — | `PatientDto {id, …, allergies[]}` | 200, 404 |
| GET | `/v1/patients?q=` | — | `PatientDto[]` | 200 |
| PATCH | `/v1/patients/{id}` | `PatientUpdateDto {…}` | `PatientDto` | 200, 400 (incl. `invalid_dob`), 404 |
| POST | `/v1/patients/{id}/allergies` | `AllergyDto {substance, severity}` | `AllergyDto` | 201, 404 |
| GET | `/v1/patients/{id}/medical-record` | — | `MedicalRecordDto {entries[]}` | 200, 404 |
| POST | `/v1/appointments` | `AppointmentDto {patientId, doctorId, slot, type}` | `AppointmentDto {id, …}` | 201, 409 (overlap / out-of-hours) |
| GET | `/v1/appointments?doctorId=&from=&to=` | — | `AppointmentDto[]` | 200 |
| PATCH | `/v1/appointments/{id}` | `AppointmentPatchDto {slot?, status?}` | `AppointmentDto` | 200, 404, 409 |
| DELETE | `/v1/appointments/{id}` | — | — | 204, 404 |
| POST | `/v1/admissions` | `AdmissionDto {patientId, roomId}` | `AdmissionDto {id, status}` | 201, 409 (gender / capacity) |
| PATCH | `/v1/admissions/{id}/transfer` | `TransferDto {roomId}` | `AdmissionDto` | 200, 409 |
| POST | `/v1/admissions/{id}/discharge` | — | `AdmissionDto {status:"Discharged"}` | 200, 409 (unpaid bills) |
| POST | `/v1/prescriptions` | `PrescriptionDto {patientId, lines[]}` | `PrescriptionDto {id, …}` | 201, **409** (allergy conflict) |
| GET | `/v1/patients/{id}/prescriptions` | — | `PrescriptionDto[]` | 200, 404 |
| POST | `/v1/bills` | `BillDto {patientId, lines[]}` | `BillDto {id, total, status}` | 201, 400 |
| POST | `/v1/bills/{id}/settle` | `PaymentDto {amount, method}` | `BillDto {status:"Settled"}` | 200, 404, 409 |
| GET | `/v1/patients/{id}/bills` | — | `BillDto[]` | 200, 404 |
| POST | `/v1/bills/export/insurance` | `ExportRequestDto {insurerId, from, to}` | `ExportDto {url, count, signature}` | 202, 400, 403 |
| POST | `/v1/pharmacy/medications` | `MedicationDto {name, price, stock}` | `MedicationDto` | 201, 400 |
| PATCH | `/v1/pharmacy/medications/{id}/stock` | `StockDto {delta}` | `MedicationDto` | 200, 409 (would go negative) |
| POST | `/v1/ambulances` | `AmbulanceDto {plate, status}` | `AmbulanceDto` | 201, 409 (duplicate plate) |
| POST | `/v1/ambulances/{id}/dispatch` | `DispatchDto {patientId, address}` | `AmbulanceTripDto` | 201, 404 |
| GET | `/v1/staff/doctors` | — | `DoctorDto[]` | 200 |
| POST | `/v1/staff/doctors` | `DoctorDto {fullName, email, departmentId}` | `DoctorDto` | 201, 400 (email policy), 409 |
| GET | `/v1/admin/audit?since=` | — | `AuditEntry[]` | 200, 403 |

### 5.2 RBAC Matrix
Cell values: ✓ = Allow, ✗ = Deny. Roles are exactly the internal-actor set from Lab 1(Receptionist, Doctor, Billing Officer, Supply Clerk, Ambulance Manager, HR, Admin). No Patient column: patients are external stakeholders only and do not authenticate against this API in v1.

*Table 3.4. RBAC Matrix*

| Endpoint | Anon | Recept. | Doctor | Billing | Supply | Amb. Mgr | HR | Admin |
| :-- | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
| `POST /v1/auth/login` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| `POST /v1/auth/refresh` | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| `POST /v1/patients` | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/patients/{id}` | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/patients?q=` | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `PATCH /v1/patients/{id}` | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/patients/{id}/allergies` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/patients/{id}/medical-record` | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/appointments` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/appointments` | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `PATCH /v1/appointments/{id}` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `DELETE /v1/appointments/{id}` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/admissions` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `PATCH /v1/admissions/{id}/transfer` | ✗ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/admissions/{id}/discharge` | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/prescriptions` | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/patients/{id}/prescriptions` | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/bills` | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/bills/{id}/settle` | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `GET /v1/patients/{id}/bills` | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/bills/export/insurance` | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✓ |
| `POST /v1/pharmacy/medications` | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✓ |
| `PATCH /v1/pharmacy/medications/{id}/stock` | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✓ |
| `POST /v1/ambulances` | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ | ✓ |
| `POST /v1/ambulances/{id}/dispatch` | ✗ | ✓ | ✗ | ✗ | ✗ | ✓ | ✗ | ✓ |
| `GET /v1/staff/doctors` | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✓ | ✓ |
| `POST /v1/staff/doctors` | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ | ✓ |
| `GET /v1/admin/audit` | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ |

**Authorization policy notes.**
1. Role enforcement is policy-based at the API layer (ASP.NET Core `[Authorize(Policy="...")]`); the same role claims drive sidebar filtering in the staff portal.
2. `409 Conflict` responses (allergy block, business-hours, gender mismatch, unpaid bill) are returned independently of role — i.e. an Admin cannot override an allergy block via the API.
3. The role-to-nav mapping observed in the working prototype (`Receptionist → dashboard/patients/appointments/admissions/ambulance`, `Doctor → dashboard/patients/appointments/prescriptions/admissions`, `Billing → dashboard/patients/billing/pharmacy`, `Admin → all`) is a *subset* of this matrix: it grants page-level visibility; the API matrix above is the authoritative action-level policy.

---
[back](../README.md)
