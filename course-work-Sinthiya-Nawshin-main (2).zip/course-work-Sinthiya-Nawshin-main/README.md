[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/eVa8nvCC)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=22726257)
# Information Systems Analysis and Design - Laboratory Works
This repository provides a structured approach to laboratory works for the course of Information Systems Analysis and Design - from understanding a business domain to architecting a solution, designing its components, planning its deployment, and developing a working prototype.

- **Instructor**: Kęstutis Normantas (kestutis.normantas@vilniustech.lt)
- **Due**: Please refer to the course schedule for the due dates for the intermediate and final submissions.
- **Submission**: Ensure your changes are pushed to the default branch (main) before the deadlines.
    - **Intermediate** review: **Lab 1** and **Lab 2**
    - **Final** review: **Lab 3** and **Lab 4**
    - **Prototype** review: independent from labs, but preferably aligned with the course plan.

    - **Course Work** involves all four lab works along with prototype as a whole.
- **Feedback**: A dedicated Pull Request will be automatically enabled to ensure the feedback loop for the assignment (feedback comments, assignment questions, etc.).

## Course Labs

- [**Lab 1 — Business Domain Analysis**](/lab1-domain-analysis/domain-analysis.md): Understand the problem domain, define underlying business goals, main stakeholders, essential features and identify domain boundaries.
- [**Lab 2 — Solution Architecture**](/lab2-solution-architecture/solution-architecture.md): Define quality goals, solution strategy, and architecture views.
- [**Lab 3 — Solution Design**](/lab3-solution-design/solution-design.md): Specify solution features, user interfaces, module structure, data models, and run-time.
- [**Lab 4 — Solution Deployment**](/lab4-solution-deployment/solution-deployment.md): Plan infrastructure and deployment approach.

- [**Solution Prototype**](/solution-prototype/README.md): Working implementation demonstrating core functionality.


## Resources
- [Learn with GitHub Classrom](https://docs.github.com/en/education/manage-coursework-with-github-classroom/learn-with-github-classroom)
- [UML Spec](https://www.omg.org/spec/UML)
- [UML Diagrams](https://www.uml-diagrams.org/)
- [C4 Model](https://c4model.com)
- [BMM Spec](https://www.omg.org/spec/BMM)
- [Draw IO](https://www.drawio.com/)
- [Plant UML](https://plantuml.com/)
- [Mermaid](https://mermaid.js.org/intro/syntax-reference.html)
- [Structurizr DSL (C4)](https://docs.structurizr.com/dsl)

For more resources please refer to the course module in the Moodle.

