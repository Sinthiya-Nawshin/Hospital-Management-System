# Solution Prototype — Meridian HMS

A working interactive prototype of the Hospital Management System (HMS) staff portal. It demonstrates the role-aware UI, the navigation and information architecture from Lab 2, and the client-side enactment of the clinical safety rules specified in Lab 1 (allergy block, business-hours band, gender-based room allocation, discharge clearance).

Here is a quick run-down of the system:
- **Frontend:** The application is built with React, using a component-based architecture to handle complex views like admissions, patient records, and appointments.
- **Data Handling:** For data handling, a modular approach was taken to manage state and data, utilizing dedicated data files (data.jsx) to simulate API interactions and demonstrate the system's logic.
- **Styling:** The interface was styled with custom CSS to for a clean, professional look suitable for a hospital management environment.
- **Deployment:** The system is deployed on Vercel, which provides a streamlined CI/CD pipeline for React applications.

- **Live demo:** https://hospital-management-system-demo.vercel.app/
- **Source repository:** https://github.com/Sinthiya-Nawshin/Hospital-Management-System-demo

This folder contains a self-contained copy of the same source, so a reviewer can run the prototype locally without cloning the external repository.

## What the prototype demonstrates

| Lab 1 feature | Where to see it in the prototype |
| :-- | :-- |
| Patient Registration | Patients page → patient list + detail panel. |
| Appointment Scheduling | Appointments page — week view, "Business hours 09:00–17:00" banner, colour-coded appointment types. |
| Inpatient Admission (gender rule) | Admissions page — room board, rooms colour-coded by `allowedGender`. |
| Prescription with Allergy Check (UC-PRESC-01) | Prescriptions page — selecting a medication that conflicts with a patient allergy shows an `AllergyBadge` and disables the **Sign** button. |
| Billing & Discharge Clearance | Billing screen on the misc page. |
| Pharmacy Inventory | Pharmacy screen — non-negative stock and positive price. |
| Ambulance Fleet | Ambulance screen — unique-plate registry. |
| Staff & Department tracking | Staff screen — doctor directory grouped by department, hospital-email policy. |
| Role-filtered navigation | Top-right avatar switches role (Reception / Doctor / Billing / Admin); sidebar items change accordingly. |

## Tech stack

| Layer | Technology | Notes |
| :-- | :-- | :-- |
| Markup | Single `client/index.html` with `#root` mount | — |
| Component runtime | React 18 (UMD build, loaded via `<script>`) | No bundler required. |
| JSX transform | Babel-standalone 7.29 (in-browser) | Lets `<script type="text/babel">` work without a build step. |
| Styling | Hand-written `client/styles.css` | Inter + JetBrains Mono fonts from Google. |
| State | Local React state + a seed dataset in `client/data.jsx` | No persistence — refresh resets data except for the few keys saved to `localStorage` (role, page, auth flag, tour state). |
| Hosting | Vercel (CDN edge) for the live demo | Auto-deploys from `main`. |

This is a stand-in for the production stack defined in Lab 2 (React + TypeScript SPA, ASP.NET Core API, Azure SQL Database, OIDC, Hangfire worker). See `server/README.md` and `db/README.md` for what is intentionally out of scope.

## Folder structure

```
solution-prototype/
├── README.md                       ← this file
├── client/                         ← working static prototype (run this)
│   ├── index.html                  ← entry point; loads React + Babel from CDN
│   ├── app.jsx                     ← root component: auth, role, page state, layout
│   ├── app-shell.jsx               ← TopBar, Sidebar, role switcher, NAV definition
│   ├── shared.jsx                  ← reusable Icon, Badge, Toast, KPI primitives
│   ├── data.jsx                    ← seed data (departments, doctors, patients, medications, rooms, bills…)
│   ├── styles.css                  ← all styling (single file)
│   ├── demo-scenarios.jsx          ← "Scenarios" button on TopBar — scripted demo flows
│   ├── design-canvas.jsx           ← design tooling (not part of user-facing app)
│   ├── page-login.jsx              ← Login screen
│   ├── page-dashboard.jsx          ← Dashboard with KPIs and today's schedule
│   ├── page-patients.jsx           ← Patients list + detail tabs (Overview / History / Prescriptions / Admissions / Bills)
│   ├── page-appointments.jsx      ← Calendar (Day / Week view), business-hours band
│   ├── page-admissions.jsx        ← Room board, gender-coded rooms, transfer/discharge actions
│   ├── page-prescriptions.jsx     ← Issue prescription + allergy block (UC-PRESC-01)
│   └── page-misc.jsx              ← Billing / Pharmacy / Ambulance / Staff screens
├── server/                         ← target architecture only (see server/README.md)
│   └── README.md
└── db/                             ← target architecture only (see db/README.md)
    └── README.md
```

## How to run

You need a modern Chromium-based browser. Two options:

**Option A — direct file open (fastest)**

```bash
open solution-prototype/client/index.html
```

This works because everything is loaded from a CDN and Babel-standalone transforms `JSX` in the browser. No build step.

**Option B — local static server (recommended for a clean URL and no `file://` warnings)**

```bash
npx serve solution-prototype/client
# → http://localhost:3000
```

or any equivalent (`python3 -m http.server`, `live-server`, VS Code Live Server extension, etc.).

The first page is a Login screen; press **Sign in** with any credentials (auth is a `localStorage.setItem("hms.authed","1")` toggle — see `client/app.jsx:6`).

## How to verify each feature

The scripted-demo button ("Scenarios" on the top bar) walks you through several of these automatically. Manual steps below mirror Lab 3 & 1 (Use cases) and Lab 1 & 4 (Essential Features):

1. **Role-aware navigation** — top-right avatar → switch between Reception / Doctor / Billing / Admin. Confirm the sidebar shows different items per role (e.g. Doctor sees Prescriptions, Billing sees Pharmacy, Reception sees Ambulance).

2. **Patient Registration** — sidebar → **Patients**. The list shows 12 seeded patients; allergies are flagged with a warning icon. Open any patient to see the detail tabs.

3. **Appointment Scheduling + business-hours rule** — sidebar → **Appointments**. The week view shows the "Business hours 09:00–17:00" banner and colour-coded appointment types (Consultation / Follow-up / Check-in / Procedure / Urgent).

4. **Allergy block (UC-PRESC-01 — the headline safety scenario)** — switch role to **Doctor** → sidebar → **Prescriptions** → pick patient **`Eleanor Marsh (P-00412)`** (allergic to *Penicillin, Latex*) → add medication **Amoxicillin 500mg** → a red `AllergyBadge` appears next to the line and the **Sign** button is disabled. The matching algorithm is in `client/page-prescriptions.jsx:23–34` and consults `Patient.allergies` against `Medication.interacts`, `Medication.name`, and `Medication.class`.

5. **Room allocation by gender rule** — sidebar → **Admissions**. Rooms are colour-coded by their `allowedGender`; admitting a patient whose gender does not match is blocked at the room level.

6. **Discharge with billing clearance** — sidebar → **Billing**. Patients with unpaid bills cannot be cleared for discharge; settling the bill removes the block.

7. **Pharmacy stock** — sidebar → **Pharmacy**. Medication list shows price and stock; stock items below `reorder` level are flagged. Negative stock and zero/negative price are rejected at the form level.

8. **Ambulance unique-plate registry** — sidebar → **Ambulance**. Vehicle list with status (available / dispatched / maintenance).

9. **Staff directory + hospital-email policy** — sidebar → **Staff**. All seeded doctors use the `@hospital.org` domain.

## What is intentionally NOT in the prototype

- **No backend.** No `.NET` API, no controllers, no EF Core. The 26 REST endpoints in Lab 3.1 are design intent for the next iteration.
- **No database.** No SQL Server / Azure SQL instance, no ECA triggers. The clinical safety rules are enforced in JSX on the client (allergy block, business hours, room gender, discharge clearance, stock positivity).
- **No real authentication.** Sign-in is a `localStorage` flag; role switching is a UI control, not an OIDC token exchange.
- **No persistence.** A page refresh resets state except for the four keys in `client/app.jsx:6–8,12` (`hms.authed`, `hms.role`, `hms.page`, `hms.tour-done`).
- **No real integrations.** Insurance export, SMS/email notifications, pharmacy supplier API, App Insights — all design-time only (see Lab 4 Fig. 4.1).

The full target topology is in `lab4-solution-deployment/solution-deployment.md` Figure 4.1 and Table 4.3 (ADRs).

## Mapping back to the labs

- **Lab 1** — domain model, essential features, stakeholders, ECA safety rules: `../lab1-domain-analysis/domain-analysis.md`.
- **Lab 2** — quality goals, modular monolith strategy, C4 Context / Containers / Components, IA: `../lab2-solution-architecture/solution-architecture-solution.md`.
- **Lab 3** — use cases, wireframes (sourced from this prototype), component diagrams, domain class diagram, state machine, sequence diagram, API spec, RBAC matrix: `../lab3-solution-design/solution-design.md`.
- **Lab 4** — deployment view, ADRs, verification checklist: `../lab4-solution-deployment/solution-deployment.md`.

---
[back](../README.md)
