# Database (target architecture — not implemented in this iteration)

Lab 1's introduction commits the system to a normalised MS SQL Server database with ECA (Event-Condition-Action) triggers as the last line of defence for clinical safety rules. Lab 2 §2 and Lab 4 ADR-003 keep this choice and target **Azure SQL Database** (MS SQL-compatible) for cloud deployments.

The database tier is **not implemented** in this iteration of the prototype — the client-side enforces the same rules in JSX so the UX can be reviewed end-to-end (see `../client/page-prescriptions.jsx` for the allergy-check algorithm).

The design artefacts that describe what should live here:

- **Schema** — Lab 1 Conceptual Model and the UML Class Diagram in `lab3-solution-design/assets/hms-domain-model.drawio`. Aggregates: Patient, Appointment, Admission, Prescription, Bill, plus supporting entities (Allergy, Room, Medication, Ambulance, Department, Doctor).
- **ECA rules to implement as triggers**:
  - `Patient.dob ≤ today` (CHECK + trigger).
  - `Appointment.slot ∈ businessHours` (09:00–17:00) + "no overlap per doctor".
  - `Admission.room.allowedGender == patient.gender`.
  - `Discharge ⇒ no unpaid bills` (DischargeClearancePolicy enforced at the DB level too).
  - `Prescription` blocks insert when any line conflicts with `Patient.Allergies`.
  - `Medication.price > 0`, `Medication.stock ≥ 0`.
  - `Ambulance.plate` unique.
  - `Doctor.email` matches hospital domain (HR policy).
- **Normalisation** — 3NF (Lab 1 Introduction, Lab 4 ADR-003).
- **Deployment** — Azure SQL via private endpoint inside a VNet (Lab 4 Fig. 4.1).
