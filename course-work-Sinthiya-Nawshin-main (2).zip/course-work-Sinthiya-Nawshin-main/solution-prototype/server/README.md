# Server (target architecture — not implemented in this iteration)

The Solution Architecture (Lab 2 §2, §4) and the Deployment View (Lab 4 §1) define a server tier consisting of:

- **HMS API** — ASP.NET Core 8 Web API hosted on Azure App Service.
- **Identity Provider** — ASP.NET Core Identity / OIDC, co-located with the API in v1.
- **Notification Worker** — Hangfire process for appointment reminders, discharge notices, and restock alerts.

This iteration of the prototype demonstrates the staff-portal UI and the client-side enforcement of clinical safety rules (allergy block, business-hours band, gender-based room allocation, discharge clearance). The server tier above is the next implementation step; it is intentionally out of scope for the prototype review.

See:
- API specification — `lab3-solution-design/solution-design.md` §5.1 (26 REST endpoints under `/api/v1/`).
- RBAC matrix — `lab3-solution-design/solution-design.md` §5.2.
- Server component diagram — `lab3-solution-design/assets/hms-server-components.drawio`.
- ADRs for the chosen technology — `lab4-solution-deployment/solution-deployment.md` Table 4.3 (ADR-004, ADR-007, ADR-010).
