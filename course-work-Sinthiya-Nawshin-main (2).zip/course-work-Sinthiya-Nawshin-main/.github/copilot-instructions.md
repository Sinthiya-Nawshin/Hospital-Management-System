# Copilot Instructions for isad-2026

## Project Overview
This repository is structured as a series of labs for the ISAD-2026 course, focusing on business analysis, solution architecture, UI design, prototyping, and deployment. Each lab is organized in its own directory, with supporting documentation and (where applicable) code or configuration files.

## Structure and Major Components
- **lab1-domain-analysis/**: Domain analysis documentation.
- **lab2-solution-architecture/**: Architectural views and rationale documentation.
- **lab3-solution-design/**: UI forms and App logic design documentation.
- **lab4-solution-deployment/**: Placeholder for deployment diagram, instructions or scripts.
- **solution-prototype/**: Contains three subcomponents:
  - `client/`: Intended for client-side prototype code and documentation.
  - `server/`: Intended for server-side prototype code and documentation.
  - `db/`: Intended for database schema or related documentation.


## Key Conventions
- Most directories contain only documentation (Markdown files). Code, if present, will be in `solution-prototype/client/src/` or `solution-prototype/server/`.
- All lab documentation is in Markdown. There are no build scripts, test commands, or automation present in the repository as of now.
- No external dependencies or integrations are defined in the current structure.

## Guidance for AI Agents
- **Focus on Documentation**: Most tasks will involve reading, updating, or generating Markdown documentation for each lab.
- **Respect Lab Boundaries**: Keep changes within the relevant lab directory. Do not cross-link or move files between labs unless explicitly instructed.
- **No Code Execution**: There are no build, test, or run commands to automate. Do not add scripts or automation unless requested.
- **Naming**: Follow the existing naming conventions for files and directories (e.g., `form-design.md`, `client-overview.md`).
- **Extensibility**: If adding new files, use clear, descriptive names and place them in the appropriate lab subdirectory.

## Examples
- To add a new UI form design, create a Markdown file in `lab3-solution-design/`.
- To document a new server endpoint, add a Markdown file in `solution-prototype/server/`.

## Reference
- See the top-level `README.md` for a high-level overview of the lab sequence and purpose.

---
If any conventions or workflows change, update this file to keep AI agents productive and aligned with project practices.
